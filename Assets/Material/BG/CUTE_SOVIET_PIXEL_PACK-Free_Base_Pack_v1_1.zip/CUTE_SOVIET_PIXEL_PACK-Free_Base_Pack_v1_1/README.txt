Dear comrade!
Thank you for downloading this asset pack!
I truly hope it will be useful in your project.

This is a base pack that will be expanded and updated over time.
This pack focuses on static environment assets and does not include animations.
You may notice similar objects with small visual differences —
these variations are intentional and designed to add visual diversity
to your scenes.
If you’d like to follow future updates and new releases, you can find me here:
https://redtramway.itch.io/

Thank you once again for your support.
It genuinely motivates me to keep creating.